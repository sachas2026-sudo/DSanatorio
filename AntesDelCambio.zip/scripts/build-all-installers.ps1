# Compila y genera los instaladores de Sanatorio:
# 1. Server (Mesa de Entrada - Andrea y Mary / Servidor principal)
# 2. Cliente (Administración y Afiliados; acceso según el usuario)
param(
  [string]$DestDir = ""
)

$ErrorActionPreference = 'Stop'
$ProjectRoot = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
if (-not $DestDir) {
  $DestDir = $ProjectRoot
} else {
  $DestDir = (Resolve-Path $DestDir).Path
}

Push-Location $ProjectRoot

try {
  $pkg = Get-Content (Join-Path $ProjectRoot "package.json") | ConvertFrom-Json
  $appVer = $pkg.version
  Write-Host "=== Generando Instaladores de Sanatorio v$appVer ===" -ForegroundColor Cyan

  Write-Host "`nSincronizando bases y credenciales para instaladores..." -ForegroundColor Yellow
  npm run installer:sync-bases
  if ($LASTEXITCODE -ne 0) { throw "Fallo la sincronizacion de bases del instalador" }

  # 1. Server (Mesa de Entrada - Andrea y Mary / Servidor principal)
  Write-Host "`n[1/3] Compilando Sanatorio Server (Mesa de Entrada)..." -ForegroundColor Yellow
  $env:VITE_APP_FLAVOR = "server"
  npx tauri build -c src-tauri/tauri.server.conf.json
  if ($LASTEXITCODE -ne 0) { throw "Fallo la compilacion de Sanatorio Server" }
  $srcServer = Join-Path $ProjectRoot "src-tauri\target\release\bundle\nsis\Sanatorio Server_${appVer}_x64-setup.exe"
  Copy-Item $srcServer (Join-Path $DestDir "Sanatorio_Server_${appVer}.exe") -Force
  Write-Host "Listo: Sanatorio_Server_${appVer}.exe" -ForegroundColor Green

  # 2. Cliente (una aplicación para Administración y Afiliados)
  Write-Host "`n[2/2] Compilando Sanatorio Cliente..." -ForegroundColor Yellow
  $env:VITE_APP_FLAVOR = "administrador"
  npx tauri build -c src-tauri/tauri.cliente.conf.json
  if ($LASTEXITCODE -ne 0) { throw "Fallo la compilacion de Sanatorio Cliente" }
  $srcClient = Join-Path $ProjectRoot "src-tauri\target\release\bundle\nsis\Sanatorio Cliente_${appVer}_x64-setup.exe"
  Copy-Item $srcClient (Join-Path $DestDir "Sanatorio_Cliente_V${appVer}.exe") -Force
  Write-Host "Listo: Sanatorio_Cliente_V${appVer}.exe" -ForegroundColor Green

  Write-Host "`n=== Los instaladores Server y Cliente quedaron listos en $DestDir ===" -ForegroundColor Green
}
finally {
  Remove-Item Env:VITE_APP_FLAVOR -ErrorAction SilentlyContinue
  Pop-Location
}
