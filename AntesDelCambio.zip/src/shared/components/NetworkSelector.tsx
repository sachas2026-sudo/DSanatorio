import { useCallback, useEffect, useState } from 'react'
import {
  autoConnectServer,
  discoverServers,
  getLocalNetworkInfo,
  getNetworkConnectionStatus,
  setManualServerUrl,
  type DiscoveredServer,
  type LocalNetworkInfo,
  type NetworkInterfaceInfo,
  type NetworkStatusInfo,
} from '../../lib/networkDiscovery'
import { setModeLocal } from '../../lib/appMode'
import { APP_VERSION } from '../../lib/appVersion'
import './network-selector.css'

type NetworkSelectorProps = {
  onOpenInfo?: () => void
  appVersion?: string
}

function extractSubnetPrefix(ipOrUrl: string): string | null {
  if (!ipOrUrl) return null
  const clean = ipOrUrl
    .trim()
    .replace(/^https?:\/\//, '')
    .split(':')[0]
    .split('/')[0]
  const parts = clean.split('.')
  if (parts.length === 4 && parts.every((p) => /^\d+$/.test(p))) {
    return `${parts[0]}.${parts[1]}.${parts[2]}`
  }
  return null
}

export function NetworkSelector({ onOpenInfo, appVersion = APP_VERSION }: NetworkSelectorProps) {
  const [status, setStatus] = useState<NetworkStatusInfo | null>(null)
  const [localNet, setLocalNet] = useState<LocalNetworkInfo | null>(null)
  const [multipleServers, setMultipleServers] = useState<DiscoveredServer[] | null>(null)
  const [open, setOpen] = useState(false)
  const [busy, setBusy] = useState(false)
  const [message, setMessage] = useState<{ type: 'ok' | 'err'; text: string } | null>(null)
  const [manualIp, setManualIp] = useState('')
  const [copiedDiag, setCopiedDiag] = useState(false)

  const checkStatus = useCallback(async () => {
    try {
      const s = await getNetworkConnectionStatus()
      setStatus(s)
      if (s?.serverUrl) {
        const clean = s.serverUrl.replace(/^https?:\/\//, '').split('/')[0]
        setManualIp(clean)
      }
    } catch {
      // ignore
    }
  }, [])

  const refreshLocalNet = useCallback(async () => {
    try {
      const info = await getLocalNetworkInfo()
      setLocalNet(info)
      return info
    } catch {
      return null
    }
  }, [])

  useEffect(() => {
    void checkStatus()
    void refreshLocalNet()
    const timer = setInterval(() => {
      void checkStatus()
    }, 12000)
    return () => clearInterval(timer)
  }, [checkStatus, refreshLocalNet])

  useEffect(() => {
    if (open) {
      void checkStatus()
      void refreshLocalNet()
    }
  }, [open, checkStatus, refreshLocalNet])

  const isOnline = status?.isOnline ?? false
  const isHost = status?.isServerHost ?? false

  async function handleRefreshAndConnect() {
    if (busy) return
    setBusy(true)
    setMessage(null)
    setMultipleServers(null)

    try {
      // 1. Vuelve a leer las interfaces de red de esta PC y actualiza las tarjetas
      const netInfo = await refreshLocalNet()

      if (isHost) {
        // En PC Servidor: confirma que el servidor escucha en 0.0.0.0:8787
        await checkStatus()
        setMessage({
          type: 'ok',
          text: 'Interfaces de red actualizadas. Servidor activo escuchando en 0.0.0.0:8787.',
        })
      } else {
        // En PC Cliente: busca el servidor en la red actual en el orden especificado
        const servers = await discoverServers(3500)

        if (servers.length === 0) {
          // Si no lo encuentra: estado Desconectado y deja la IP anterior sin borrarla
          await checkStatus()
          setMessage({
            type: 'err',
            text: 'No se encontró servidor en esta red',
          })
        } else if (servers.length === 1) {
          // Un único servidor encontrado: conectar automáticamente
          const srv = servers[0]
          await setManualServerUrl(srv.serverUrl)
          setManualIp(`${srv.ip}:8787`)
          await checkStatus()
          setMessage({
            type: 'ok',
            text: `Conectado a ${srv.ip}:8787`,
          })
        } else {
          // Varios servidores encontrados: mostrar lista para elegir
          setMultipleServers(servers)
          setMessage({
            type: 'ok',
            text: `Se encontraron ${servers.length} servidores en la red local. Elegí a cuál conectarte:`,
          })
        }
      }
    } catch (err) {
      setMessage({
        type: 'err',
        text: err instanceof Error ? err.message : 'No se pudo completar la búsqueda en la red.',
      })
    } finally {
      setBusy(false)
    }
  }

  async function handleSelectServer(srv: DiscoveredServer) {
    if (busy) return
    setBusy(true)
    setMessage(null)
    try {
      await setManualServerUrl(srv.serverUrl)
      setManualIp(`${srv.ip}:8787`)
      setMultipleServers(null)
      await checkStatus()
      setMessage({
        type: 'ok',
        text: `Conectado a ${srv.ip}:8787`,
      })
    } catch (err) {
      setMessage({
        type: 'err',
        text: err instanceof Error ? err.message : 'Error al conectar al servidor seleccionado.',
      })
    } finally {
      setBusy(false)
    }
  }

  async function handleManualConnect() {
    if (!manualIp.trim() || busy) return
    setBusy(true)
    setMessage(null)
    try {
      let target = manualIp.trim()
      if (!target.startsWith('http://') && !target.startsWith('https://')) {
        target = `https://${target}`
      }
      if (!target.includes(':8787') && !target.slice(8).includes(':')) {
        target = `${target}:8787`
      }
      await setManualServerUrl(target)
      await checkStatus()
      setMessage({ type: 'ok', text: 'Dirección de servidor guardada y verificada.' })
    } catch (err) {
      setMessage({
        type: 'err',
        text: err instanceof Error ? err.message : 'No se pudo conectar a la dirección indicada.',
      })
    } finally {
      setBusy(false)
    }
  }

  // Verificación de subred entre la IP manual y las interfaces locales
  const manualSubnet = extractSubnetPrefix(manualIp)
  const localSubnets = (localNet?.interfaces || [])
    .map((i) => extractSubnetPrefix(i.ip))
    .filter((s): s is string => s !== null)

  const isDifferentSubnet =
    manualSubnet !== null && localSubnets.length > 0 && !localSubnets.includes(manualSubnet)

  function handleCopyDiagnostics() {
    const timestamp = new Date().toLocaleString('es-AR')
    const ifacesText = (localNet?.interfaces || [])
      .map(
        (i) =>
          `  - Adaptador: ${i.name} ${i.isPrimary ? '(Principal)' : ''}\n    IP: ${i.ip}\n    Máscara: ${i.mask}\n    Puerta de enlace: ${i.gateway || '—'}\n    Dirección Sanatorio: ${i.serverEndpoint}`,
      )
      .join('\n\n')

    const serversText = (multipleServers || [])
      .map((s) => `  - ${s.serverName} (${s.ip}:${s.port})`)
      .join('\n')

    const diag = `=== DIAGNÓSTICO DE RED SANATORIO ===
Fecha: ${timestamp}
Versión: v${appVersion}
Modo: ${isHost ? 'PC Servidor (Principal)' : 'Terminal Cliente'}
Estado de conexión: ${isOnline ? 'En línea' : 'Desconectado'}
Servidor configurado: ${status?.serverUrl || 'Ninguno'}
Detalle: ${status?.message || '—'}

--- Interfaces de Red de esta PC ---
${ifacesText || '  (No se detectaron interfaces)'}

--- Servidores detectados en la red ---
${serversText || '  (Ninguno)'}
======================================`

    if (navigator?.clipboard?.writeText) {
      void navigator.clipboard.writeText(diag)
      setCopiedDiag(true)
      setTimeout(() => setCopiedDiag(false), 3000)
    }
  }

  const tooltipText = isHost
    ? 'Servidor principal (en línea)'
    : isOnline
      ? `Conectado al servidor (${status?.serverUrl ?? ''})`
      : 'Servidor desconectado (buscando en red local)'

  return (
    <>
      <div className="sidebar-footer-row">
        <button
          type="button"
          className="sidebar-server-btn"
          onClick={() => {
            setMessage(null)
            setOpen(true)
          }}
          title={tooltipText}
          aria-label={isOnline ? 'Servidor activo' : 'Servidor inactivo'}
        >
          <svg
            className="sidebar-server-wifi-icon"
            width="15"
            height="15"
            viewBox="0 0 24 24"
            fill="none"
            stroke={isOnline ? 'var(--menu-ok, #2E7D4F)' : 'var(--menu-peligro, #B3261E)'}
            strokeWidth="2.2"
            strokeLinecap="round"
            strokeLinejoin="round"
            aria-hidden="true"
          >
            <path d="M5 12.55a11 11 0 0 1 14.08 0" />
            <path d="M1.42 9a16 16 0 0 1 21.16 0" />
            <path d="M8.53 16.11a6 6 0 0 1 6.95 0" />
            <circle
              cx="12"
              cy="20"
              r="1.5"
              fill={isOnline ? 'var(--menu-ok, #2E7D4F)' : 'var(--menu-peligro, #B3261E)'}
              stroke="none"
            />
          </svg>
          <span
            className="sidebar-server-status-text"
            style={{
              color: isOnline ? 'var(--menu-ok, #2E7D4F)' : 'var(--menu-peligro, #B3261E)',
              fontWeight: 500,
            }}
          >
            {isOnline ? 'Servidor activo' : 'Servidor inactivo'}
          </span>
        </button>

        {onOpenInfo && (
          <button
            type="button"
            className="sidebar-f1-btn"
            title="Versión y atajos (F1)"
            onClick={onOpenInfo}
          >
            v{appVersion} · F1 ayuda
          </button>
        )}
      </div>

      {open && (
        <div className="network-dialog-overlay" onClick={() => setOpen(false)}>
          <div className="network-dialog" onClick={(e) => e.stopPropagation()}>
            <h2>
              <span
                className={`network-indicator__dot ${
                  isOnline ? 'network-indicator__dot--online' : 'network-indicator__dot--offline'
                }`}
                style={{ position: 'static', display: 'inline-block' }}
              />
              Estado de Red y Servidor
            </h2>

            <div className="network-dialog__rows">
              <div className="network-dialog__row">
                <span className="network-dialog__label">Estado de conexión</span>
                <div className="network-dialog__value">
                  <span
                    className={`network-badge ${
                      isOnline ? 'network-badge--online' : 'network-badge--offline'
                    }`}
                  >
                    {isOnline
                      ? status?.serverUrl
                        ? `Conectado a ${status.serverUrl.replace(/^https?:\/\//, '').split('/')[0]}`
                        : 'En línea'
                      : 'Desconectado'}
                  </span>
                </div>
              </div>

              <div className="network-dialog__row">
                <span className="network-dialog__label">Modo</span>
                <span className="network-dialog__value">
                  {isHost ? 'PC Servidor (Principal)' : 'Terminal Cliente'}
                </span>
              </div>

              {status?.serverUrl && (
                <div className="network-dialog__row">
                  <span className="network-dialog__label">Dirección servidor</span>
                  <span className="network-dialog__value font-mono">
                    {status.serverUrl}
                  </span>
                </div>
              )}

              <div className="network-dialog__row">
                <span className="network-dialog__label">Detalle</span>
                <span className="network-dialog__value">{status?.message || '—'}</span>
              </div>
            </div>

            {/* SECCIÓN: Configuración IP de esta PC */}
            <div className="network-section-title">
              <span>Configuración IP de esta PC</span>
            </div>

            {localNet && localNet.interfaces.length > 0 ? (
              <div className="network-cards-grid">
                {localNet.interfaces.map((iface, idx) => (
                  <div
                    key={`${iface.ip}-${idx}`}
                    className={`network-card ${iface.isPrimary ? 'network-card--primary' : ''}`}
                  >
                    <div className="network-card__header">
                      <span>{iface.name}</span>
                      {iface.isPrimary && (
                        <span className="network-card__badge-primary">Principal</span>
                      )}
                    </div>
                    <div className="network-card__details">
                      <div className="network-card__detail-item">
                        <span>IP:</span>
                        <strong>{iface.ip}</strong>
                      </div>
                      <div className="network-card__detail-item">
                        <span>Máscara:</span>
                        <strong>{iface.mask}</strong>
                      </div>
                      <div className="network-card__detail-item">
                        <span>Gateway:</span>
                        <strong>{iface.gateway || '—'}</strong>
                      </div>
                      <div className="network-card__detail-item">
                        <span>Dirección:</span>
                        <strong>{iface.serverEndpoint}</strong>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p style={{ fontSize: '0.78rem', color: '#64748b', margin: '0.4rem 0' }}>
                Cargando adaptadores de red de esta PC...
              </p>
            )}

            {/* Mensajes de estado */}
            {message && (
              <div
                className={`network-message network-message--${message.type}`}
                role="alert"
              >
                {message.text}
              </div>
            )}

            {/* Lista interactiva si se encontraron múltiples servidores en la red */}
            {multipleServers && multipleServers.length > 1 && (
              <div className="network-multiple-servers">
                <div className="network-multiple-servers__title">
                  Servidores disponibles en la red local:
                </div>
                {multipleServers.map((srv, idx) => (
                  <div key={`${srv.serverUrl}-${idx}`} className="network-server-choice-item">
                    <div>
                      <strong>{srv.serverName}</strong> — <code>{srv.ip}:{srv.port}</code>
                    </div>
                    <button
                      type="button"
                      onClick={() => void handleSelectServer(srv)}
                      disabled={busy}
                    >
                      Conectar
                    </button>
                  </div>
                ))}
              </div>
            )}

            {/* Conexión manual o conmutación a local */}
            {!isHost && (
              <div className="network-dialog__actions">
                <div style={{ marginBottom: '8px' }}>
                  <button
                    type="button"
                    onClick={async () => {
                      setBusy(true)
                      try {
                        await setModeLocal()
                        setMessage({ type: 'ok', text: 'Esta PC ahora actúa como Servidor Local.' })
                        await checkStatus()
                        await refreshLocalNet()
                      } catch (e) {
                        setMessage({ type: 'err', text: String(e) })
                      } finally {
                        setBusy(false)
                      }
                    }}
                    style={{
                      width: '100%',
                      padding: '8px 12px',
                      background: '#0D766E',
                      color: '#ffffff',
                      border: 'none',
                      borderRadius: '6px',
                      fontWeight: 700,
                      cursor: 'pointer',
                      fontSize: '0.82rem',
                    }}
                    disabled={busy}
                  >
                    💻 Usar esta PC como Servidor Local (Principal)
                  </button>
                </div>

                <div className="network-manual-box">
                  <label htmlFor="manual-ip-input">Ingresar IP del Servidor manualmente:</label>
                  <div className="network-manual-row">
                    <input
                      id="manual-ip-input"
                      type="text"
                      placeholder="Ej: 192.168.1.100 o 192.168.1.100:8787"
                      value={manualIp}
                      onChange={(e) => setManualIp(e.target.value)}
                      disabled={busy}
                    />
                    <button
                      type="button"
                      onClick={() => void handleManualConnect()}
                      disabled={busy || !manualIp.trim()}
                    >
                      Guardar IP
                    </button>
                  </div>
                  {isDifferentSubnet && (
                    <div className="network-subnet-warning" role="alert">
                      <span>⚠️</span>
                      <span>
                        Esa IP está en otra red ({manualSubnet}.x vs tu red local{' '}
                        {localSubnets[0] || '192.168.1'}.x).
                      </span>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Footer con Actualizar y conectar, Copiar diagnóstico y Cerrar */}
            <div className="network-dialog__footer">
              <button
                type="button"
                className="network-action-btn network-action-btn--primary"
                onClick={() => void handleRefreshAndConnect()}
                disabled={busy}
                title="Actualiza los adaptadores de red y busca el servidor Sanatorio"
              >
                <svg
                  width="15"
                  height="15"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2.2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  aria-hidden="true"
                >
                  <path d="M5 12.55a11 11 0 0 1 14.08 0" />
                  <path d="M1.42 9a16 16 0 0 1 21.16 0" />
                  <path d="M8.53 16.11a6 6 0 0 1 6.95 0" />
                  <circle cx="12" cy="20" r="1.5" fill="currentColor" stroke="none" />
                </svg>
                {busy ? 'Buscando...' : 'Actualizar y conectar'}
              </button>

              <button
                type="button"
                className="network-action-btn network-action-btn--secondary"
                onClick={handleCopyDiagnostics}
                title="Copiar información técnica al portapapeles"
              >
                {copiedDiag ? '✓ Copiado' : 'Copiar diagnóstico'}
              </button>

              <button
                type="button"
                className="network-action-btn network-action-btn--secondary"
                onClick={() => setOpen(false)}
              >
                Cerrar
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  )
}
