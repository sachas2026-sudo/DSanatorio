import { parseAppDataJson, parseAppDataRecordWithReport, hasIntegrityIssues, formatIntegrityAlert } from './parseAppData'
import { buildObrasSocialesCatalog } from './obrasSocialesCatalog'
import { buildPrestacionesCatalog } from './prestacionesCatalog'
import {
  loadStorageRaw,
  saveStorageRaw,
  serializeAppData,
} from './appStorage'
import { migratePaymentsPorcentajeAplicado } from './paymentPorcentaje'
import { migrateSmtpSecretFromSettings } from './smtpSecret'
import type { AppData } from '../types'

export const LOAD_READ_TIMEOUT_MS = 25_000

export const EMPTY_APP_DATA: AppData = {
  patients: [],
  doctors: [],
  horarios: [],
  diasLibres: [],
  atencionesMensuales: [],
  appointments: [],
  payments: [],
  atencionesSinTurno: [],
    pagosCancelados: [],
    pagosDeudasMedicos: [],
  especialidadesCustom: [],
  obrasSociales: buildObrasSocialesCatalog([]),
  obrasSocialesCustom: [],
  localidadesCustom: [],
  motivosConsultaCustom: [],
  settings: {
    email: '',
    emailGerente: '',
    telefonoGerente: '',
    clave: '',
    telefono: '',
    cuit: '',
    supabaseUrl: 'https://mzfyzabgdlzqkvufqrxh.supabase.co',
    supabaseAnonKey: 'sb_publishable_5E4thTDbweeAZOd4wcypsw_I5O7F4fM',
    supabaseServiceRoleKey: 'sb_secret_4HAhss-rRoYWNVg9ui1haQ_v1vywr4_',
    supabaseAutoSync: true,
    supabaseUltimaSync: '',
  },
  planesAfiliados: [],
  afiliados: [],
  cuotasAfiliados: [],
  distribucionOSPercentajes: [],
  prestacionesAfiliados: buildPrestacionesCatalog([]),
  ordenesMedicas: [],
}

export function parseStoredData(raw: string): AppData {
  return parseAppDataJson(raw)
}

export type StorageLoadResult =
  | { kind: 'ok'; data: AppData; integrityAlert?: string }
  | { kind: 'empty' }
  | { kind: 'corrupt'; message: string }

export async function loadFromStorage(): Promise<StorageLoadResult> {
  try {
    let timeoutId: ReturnType<typeof window.setTimeout> | undefined
    const raw = await Promise.race([
      loadStorageRaw(),
      new Promise<string | null>((_, reject) => {
        timeoutId = window.setTimeout(
          () =>
            reject(
              new Error(
                'Tardó demasiado en leer la base de datos. Cerrá otros programas que la usen o reiniciá la PC.',
              ),
            ),
          LOAD_READ_TIMEOUT_MS,
        )
      }),
    ])
    if (timeoutId !== undefined) window.clearTimeout(timeoutId)
    if (!raw?.trim()) return { kind: 'empty' }
    try {
      const parsed = JSON.parse(raw) as unknown
      const { data, report } = parseAppDataRecordWithReport(parsed)
      const integrityAlert = hasIntegrityIssues(report)
        ? formatIntegrityAlert(report)
        : undefined
      return { kind: 'ok', data, integrityAlert }
    } catch (err) {
      const detail =
        err instanceof Error ? err.message : 'Error al interpretar el archivo.'
      return {
        kind: 'corrupt',
        message: detail,
      }
    }
  } catch (err) {
    const detail =
      err instanceof Error ? err.message : 'No se pudo leer el archivo de datos.'
    return { kind: 'corrupt', message: detail }
  }
}

export async function enrichLoadedData(data: AppData): Promise<AppData> {
  const clave = await migrateSmtpSecretFromSettings(data.settings)
  const migrated = migratePaymentsPorcentajeAplicado(data)
  return {
    ...data,
    payments: migrated.payments,
    pagosCancelados: migrated.pagosCancelados,
    pagosDeudasMedicos: data.pagosDeudasMedicos ?? [],
    atencionesSinTurno: data.atencionesSinTurno ?? [],
    planesAfiliados: data.planesAfiliados ?? [],
    afiliados: data.afiliados ?? [],
    cuotasAfiliados: data.cuotasAfiliados ?? [],
    distribucionOSPercentajes: data.distribucionOSPercentajes ?? [],
    settings: {
      ...data.settings,
      clave,
      supabaseUrl: data.settings?.supabaseUrl?.trim() || 'https://mzfyzabgdlzqkvufqrxh.supabase.co',
      supabaseAnonKey: data.settings?.supabaseAnonKey?.trim() || 'sb_publishable_5E4thTDbweeAZOd4wcypsw_I5O7F4fM',
      supabaseAutoSync: data.settings?.supabaseAutoSync !== false,
      supabaseServiceRoleKey: data.settings?.supabaseServiceRoleKey?.trim() || 'sb_secret_4HAhss-rRoYWNVg9ui1haQ_v1vywr4_',
      supabaseUltimaSync: data.settings?.supabaseUltimaSync || '',
    },
  }
}

export async function saveAppData(data: AppData): Promise<void> {
  await saveStorageRaw(serializeAppData(data))
}
