import { invoke, isTauri } from '@tauri-apps/api/core'

export interface DiscoveredServer {
  ip: string
  port: number
  serverName: string
  serverUrl: string
  certPem?: string
}

export interface NetworkStatusInfo {
  mode: 'local' | 'client'
  isOnline: boolean
  serverUrl: string | null
  serverName: string
  isServerHost: boolean
  message: string
}

export async function getNetworkConnectionStatus(): Promise<NetworkStatusInfo> {
  if (!isTauri()) {
    return {
      mode: 'local',
      isOnline: true,
      serverUrl: 'http://localhost:5173',
      serverName: 'Modo Web / Desarrollo',
      isServerHost: true,
      message: 'Ejecutando en navegador.',
    }
  }
  return invoke<NetworkStatusInfo>('get_network_connection_status')
}

export async function discoverServers(timeoutMs = 1500): Promise<DiscoveredServer[]> {
  if (!isTauri()) return []
  return invoke<DiscoveredServer[]>('discover_sanatorio_servers', { timeoutMs })
}

export async function autoConnectServer(): Promise<DiscoveredServer> {
  if (!isTauri()) {
    throw new Error('Solo disponible en la aplicación de escritorio')
  }
  return invoke<DiscoveredServer>('auto_connect_sanatorio_server')
}

export async function setManualServerUrl(url: string): Promise<void> {
  if (!isTauri()) return
  return invoke('set_manual_server_url', { url })
}

export interface NetworkInterfaceInfo {
  name: string
  ip: string
  mask: string
  gateway: string | null
  serverEndpoint: string
  isPrimary: boolean
}

export interface LocalNetworkInfo {
  interfaces: NetworkInterfaceInfo[]
  primaryIp: string | null
}

export async function getLocalNetworkInfo(): Promise<LocalNetworkInfo> {
  if (!isTauri()) {
    return {
      interfaces: [
        {
          name: 'Ethernet',
          ip: '127.0.0.1',
          mask: '255.255.255.0',
          gateway: '127.0.0.1',
          serverEndpoint: '127.0.0.1:8787',
          isPrimary: true,
        },
      ],
      primaryIp: '127.0.0.1',
    }
  }
  return invoke<LocalNetworkInfo>('get_local_network_info')
}


