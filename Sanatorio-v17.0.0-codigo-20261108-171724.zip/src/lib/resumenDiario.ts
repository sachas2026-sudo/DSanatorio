import { format, parseISO } from 'date-fns'
import type { AppData, Payment } from '../types'
import { aggregateResumenSettlementForPayments } from './paymentPorcentaje'
import { esPagoTransferencia } from './pagosPdfLayout'

export interface MedicoResumenItem {
  id?: string
  nombre: string
  especialidad?: string
  pacientes: number
  monto: number // Honorarios del médico requeridos por resumen_periodo
  totalCobrado?: number
  totalCentro?: number
  totalMedico?: number
}

export interface TurnosClasificacionItem {
  obra_social: number
  plan_plus: number
  particular: number
}

export interface TurnosClasificacion {
  atendidos: TurnosClasificacionItem
  pendientes: TurnosClasificacionItem
  cancelados: TurnosClasificacionItem
}

export interface ResumenDiarioPayload {
  fecha: string // YYYY-MM-DD
  total_cobrado: number
  total_centro: number
  total_medicos: number
  total_efectivo: number
  total_transferencia: number
  total_otros: number
  turnos_totales: number
  turnos_atendidos: number
  turnos_cancelados: number
  turnos_pendientes: number
  recaudacion_manana: number
  recaudacion_tarde: number
  recaudacion_mary: number
  recaudacion_andrea: number
  medicos_detalle: MedicoResumenItem[]
  turnos_clasificacion: TurnosClasificacion
  ultima_actualizacion: string // ISO
  origen: string
}

/**
 * Calcula el resumen gerencial/administrativo para un día específico (YYYY-MM-DD).
 */
export function calcularResumenDiario(
  data: AppData,
  fechaTarget: string = format(new Date(), 'yyyy-MM-dd'),
): ResumenDiarioPayload {
  // 1. Filtrar pagos del día
  const pagosDelDia = data.payments.filter((p) => {
    try {
      const fechaP = format(parseISO(p.fecha), 'yyyy-MM-dd')
      return fechaP === fechaTarget
    } catch {
      return false
    }
  })

  // 2. Map de nombres y porcentajes de médicos
  const doctorMap = new Map<string, { nombre: string; especialidad?: string; porcentaje?: number }>()
  for (const doc of data.doctors) {
    const nombreCompleto = `${doc.apellido}, ${doc.nombre}`.replace(/^,\s*/, '').trim() || 'Médico'
    doctorMap.set(doc.id, {
      nombre: nombreCompleto,
      especialidad: doc.especialidad,
      porcentaje: doc.porcentaje,
    })
  }

  // 3. Totales globales de pagos
  let totalCobrado = 0
  let totalCentro = 0
  let totalMedicos = 0
  let totalEfectivo = 0
  let totalTransferencia = 0
  let totalOtros = 0
  let recaudacionManana = 0
  let recaudacionTarde = 0
  let recaudacionMary = 0
  let recaudacionAndrea = 0

  // Agrupación por médico
  const pagosPorMedico = new Map<string, Payment[]>()

  for (const p of pagosDelDia) {
    const monto = Number(p.monto) || 0
    totalCobrado += monto

    // Medios de pago
    if (esPagoTransferencia(p.metodo)) {
      totalTransferencia += monto
    } else if (p.metodo.trim().toLowerCase() === 'efectivo') {
      totalEfectivo += monto
    } else {
      totalOtros += monto
    }

    // Por horario (mañana: antes de las 14:00, tarde: 14:00 en adelante)
    try {
      const hora = parseISO(p.fecha).getHours()
      if (hora < 14) {
        recaudacionManana += monto
      } else {
        recaudacionTarde += monto
      }
    } catch {
      recaudacionManana += monto
    }

    // Por usuario registrado
    const reg = (p.registradoPor || '').toLowerCase()
    if (reg.includes('mary') || reg.includes('aguirre')) {
      recaudacionMary += monto
    } else if (reg.includes('andrea') || reg.includes('barua')) {
      recaudacionAndrea += monto
    }

    // Agrupar
    const list = pagosPorMedico.get(p.doctorId) ?? []
    list.push(p)
    pagosPorMedico.set(p.doctorId, list)
  }

  // 4. Detalle y liquidación por médico
  const medicosDetalle: MedicoResumenItem[] = []
  for (const [doctorId, docPagos] of pagosPorMedico.entries()) {
    const docInfo = doctorMap.get(doctorId)
    const docNombre = docInfo?.nombre ?? 'Médico eliminado'
    const pctFallback = () => docInfo?.porcentaje

    const settlement = aggregateResumenSettlementForPayments(docPagos, pctFallback)

    const cobradoDoc = settlement.facturado
    const centroDoc = settlement.comision
    const medicoDoc = settlement.efectivoAEntregar

    totalCentro += centroDoc
    totalMedicos += medicoDoc

    medicosDetalle.push({
      id: doctorId,
      nombre: docNombre,
      especialidad: docInfo?.especialidad,
      pacientes: docPagos.length,
      monto: Math.round(medicoDoc * 100) / 100,
      totalCobrado: Math.round(cobradoDoc * 100) / 100,
      totalCentro: Math.round(centroDoc * 100) / 100,
      totalMedico: Math.round(medicoDoc * 100) / 100,
    })
  }

  // Ordenar médicos por mayor monto
  medicosDetalle.sort((a, b) => b.monto - a.monto)

  // 5. Turnos del día según la fecha local (misma lógica que la Agenda)
  const turnosDelDia = data.appointments.filter((a) => {
    try {
      return format(parseISO(a.fechaHora), 'yyyy-MM-dd') === fechaTarget
    } catch {
      return false
    }
  })

  // Mapas para clasificación unívoca de cobertura
  const patientMap = new Map((data.patients || []).map((p) => [p.id, p]))
  const afiliadosActivosSet = new Set(
    (data.afiliados || [])
      .filter((a) => a.activo !== false)
      .map((a) => a.patientId),
  )
  const planNombresSet = new Set(
    (data.planesAfiliados || []).map((pl) => pl.nombre.trim().toLowerCase()),
  )
  for (const p of ['plan estándar', 'plan estandar', 'plan plus', 'plan ultra']) {
    planNombresSet.add(p)
  }

  let turnosAtendidos = 0
  let turnosCancelados = 0
  let turnosPendientes = 0

  const clasificacion: TurnosClasificacion = {
    atendidos: { obra_social: 0, plan_plus: 0, particular: 0 },
    pendientes: { obra_social: 0, plan_plus: 0, particular: 0 },
    cancelados: { obra_social: 0, plan_plus: 0, particular: 0 },
  }

  for (const t of turnosDelDia) {
    const override = (t.obraSocialOverride || '').trim()
    const overrideNorm = override.toLowerCase()
    const patient = patientMap.get(t.patientId)
    const osPaciente = (patient?.obraSocial || '').trim()
    const osPacienteNorm = osPaciente.toLowerCase()
    const isAfiliado = afiliadosActivosSet.has(t.patientId)

    let cat: 'obra_social' | 'plan_plus' | 'particular' = 'particular'
    if (overrideNorm === 'particular') {
      cat = 'particular'
    } else if (planNombresSet.has(overrideNorm) || isAfiliado) {
      cat = 'plan_plus'
    } else if (override) {
      cat = 'obra_social'
    } else if (
      osPaciente &&
      !['particular', 'ninguna', 'sin obra social', 'no tiene', '-'].includes(osPacienteNorm)
    ) {
      cat = 'obra_social'
    } else {
      cat = 'particular'
    }

    const estado = (t.estado || '').toLowerCase().trim()
    if (estado === 'cancelado') {
      turnosCancelados++
      clasificacion.cancelados[cat]++
    } else if (estado === 'atendido') {
      turnosAtendidos++
      clasificacion.atendidos[cat]++
    } else {
      // 'programado', 'presente', o cualquier turno activo en espera de atención
      turnosPendientes++
      clasificacion.pendientes[cat]++
    }
  }

  const turnosTotales = turnosAtendidos + turnosPendientes + turnosCancelados

  return {
    fecha: fechaTarget,
    total_cobrado: Math.round(totalCobrado * 100) / 100,
    total_centro: Math.round(totalCentro * 100) / 100,
    total_medicos: Math.round(totalMedicos * 100) / 100,
    total_efectivo: Math.round(totalEfectivo * 100) / 100,
    total_transferencia: Math.round(totalTransferencia * 100) / 100,
    total_otros: Math.round(totalOtros * 100) / 100,
    turnos_totales: turnosTotales,
    turnos_atendidos: turnosAtendidos,
    turnos_cancelados: turnosCancelados,
    turnos_pendientes: turnosPendientes,
    recaudacion_manana: Math.round(recaudacionManana * 100) / 100,
    recaudacion_tarde: Math.round(recaudacionTarde * 100) / 100,
    recaudacion_mary: Math.round(recaudacionMary * 100) / 100,
    recaudacion_andrea: Math.round(recaudacionAndrea * 100) / 100,
    medicos_detalle: medicosDetalle,
    turnos_clasificacion: clasificacion,
    ultima_actualizacion: new Date().toISOString(),
    origen: `Sanatorio Desktop|${JSON.stringify(clasificacion)}`,
  }
}
